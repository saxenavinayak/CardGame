#ifndef PLAYER
#define PLAYER

#include <string>
#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Player {
private:
	int play_count;
	string current_card;
	string reserve_card;
	vector<string> draw_pile;
	vector<string> discard_pile;

public:
	Player(vector<string> vect);
	// Checks if a player has a winning deck (draw pile is empty, discard pile is empty, reserve is empty)
	bool winning_deck();
	// Switches deck from draw pile to discard pile when draw pile is empty, returns false if not possible
	bool switch_deck();
	// Switches current playing card with the card in reserve
	void switch_current_reserve();
	// Returns the card in reserve
	string get_reserve();
	// Sets reserve value to card
	void change_reserve(string card);
	// Sets reserve card to empty, adding it onto discard
	void reserve_to_discard();
	// Current playing card goes to discard
	void current_to_discard();
	// Sets a joker value
	void set_joker_value(string value);
	// Takes a head and adds it to players discard pile
	void add_head(vector<string> head);
	// Returns the top card currently playable
	string top_playing_card();
	// Changes the current playable card to card
	void set_playing_card(string card);
	// Returns size of draw pile
	int draw_size();
	// Returns size of discard pile
	int discard_size();
	// Returns the number of plays that the player has to make
	int get_play_count();
	// Sets the number of plays that hte player has to make
	void set_play_count(int play_count);
};
#endif

