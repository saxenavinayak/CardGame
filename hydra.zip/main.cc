#include <random>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm> 
#include "Player.h"
#include "Board.h"
#include "Play_Game.h"
#include "Base_print.h"
#include "TextDisplay.h"
#include <memory>

using namespace std;
const int suits = 4;
const int units = 13;
const int jokers = 2;
const int decksize = suits * units + jokers;

int main(int arguments, char* argument_count[]) {

	//Get the number of players playing the game
	int player_count = 0;
	cout << "How many players?" << endl;
	while (true) {
		if (!(cin >> player_count)) {
			if (cin.eof()) {
				cin.clear();
				cin.ignore();
				exit(0);
			} else {
				cout << "Please enter a valid number." << endl;
				cin.clear();
				cin.ignore();
			}
		} else {
			if (player_count < 2) {
				cout << "Minimum of 2 players are required to play this game." << endl;
				cout << "How many players?" << endl;
			} else {
				cout << endl;
				break;
			}
		}
	}

	// Calculate whether testing mode is on for user
	bool testing = (arguments > 1 && string(argument_count[1]) == "-testing");
	int testing_size = 0;
	if (testing) {
		cout << "How many cards will each player have?" << endl;
		while(true) {
			if (!(cin >> testing_size)) {
				if (cin.eof()) {
					cin.clear();
					cin.ignore();
					exit(0);
				} else {
					cout << "Please enter a valid number in range [1,54]." << endl;
					cin.clear();
					cin.ignore();
				}
			} else {
				if (testing_size < 1 || testing_size > decksize) {
					cout << "Card count must be in range [1,54]." << endl;
					cout << "How many cards will each player have?" << endl;
				} else {
					cout << endl;
					break;
				}
			}
		}
	}

	// Create a ptr to a new game
	shared_ptr<Board> game(new Play_Game(testing));
	// Generate a new deck
	vector<string> deck;
	game->generate_cards(&deck, player_count);

	//Initialize Players, and distribute cards
	for (int i = 0; i < player_count; i++) {
		vector<string> player_i_deck;
		if (testing) {
			// Transferring the first testing_size cards of deck into the player
			move(deck.begin(), deck.begin() + testing_size, back_inserter(player_i_deck));
			// Removes the first testing_size cards
			deck.erase(deck.begin(), deck.begin() + testing_size);
		}
		else {
			// Transferring the first 54 cards of deck into the player
			move(deck.begin(), deck.begin() + decksize, back_inserter(player_i_deck));
			// Removes the first 54 cards
			deck.erase(deck.begin(), deck.begin() + decksize);
		}
		// Create a new ptr to a plyer
		shared_ptr<Player> player(new Player(player_i_deck));
		
		// Add player to game
		game->new_player(move(player));
	}
	//Set up observers
	shared_ptr<Base_print> printObserver(nullptr);
	printObserver = std::make_shared<TextDisplay>(game);
	game->print_functions(move(printObserver));

	//Begin and end game
	game->new_game(testing);
	game->end_game();

}
