#ifndef GAMEMANAGER
#define GAMEMANAGER

#include <string>
#include <iostream>
#include <vector>
#include <map>
#include "Player.h"
#include "Board.h"
#include <memory>

using namespace std;

class Play_Game : public Board {

private:
	int player_count;
	bool testing_mode;

public:
	// Ctor
	Play_Game(bool testing);
	// Gets suit from input in testing mode
	string get_suit_testing_card();
	// Gets value from input in testing mode
	string get_testing_card();
	// Plays game in testing mode
	void game_in_testing();
	// Virtual function from board (see board.h)
	void new_game(bool test);
	// Base game begin turn
	void start_turn();
	// Draws card
	void switch_deck();
	// Prompts user to input and make a move given game condition
	void player_turn(); 
	// Places current player's card into the head
	void head_play_card(int i);
	// Takes cards from players draw and adds 2 card_heads
	void head_split();
	// Ends a players turn, making the necessary movement of cards
	void end_turn();
	// Virtual function from board (see board.h)
	void end_game();
	// Gets the play card of a given head index
	string head_card(int i);
};

#endif
