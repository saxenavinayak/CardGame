#include <string>
#include <iostream>
#include "Board.h"
#include "Play_Game.h"
#include <algorithm>
#include <random>
#include "Player.h"

using namespace std;


Player::Player(vector<string> cards) {
	for (int i = 0; i < cards.size(); i++) {
		draw_pile.push_back(cards[i]);
	}
	reserve_card = "";
	current_card = "";
	play_count = 1;
}

bool Player::winning_deck() {
	if (draw_pile.size() == 0 && discard_pile.size() == 0 && reserve_card == "") {
		return true;
	}
	return false;
}

void Player::switch_current_reserve() {
	if (reserve_card == "") {
		reserve_card = current_card;
		current_card = "";
	} else {
		string temp = reserve_card;
		reserve_card = current_card;
		current_card = temp;
	}
}

void Player::reserve_to_discard() {
	if (reserve_card != "") {
		discard_pile.push_back(reserve_card);
		reserve_card = "";
	}
}

void Player::current_to_discard() {
	if (current_card != "") {
		discard_pile.push_back(current_card);
		current_card = "";
	}
}

void Player::add_head(vector<string> head) {
	for (int i = 0; i < head.size(); i++) {
		if (head[i][head[i].size() - 1] == 'J') {
			head[i] = "joker";
		}
	}
	move(head.begin(), head.end(), back_inserter(discard_pile));
}

bool Player::switch_deck() {
	if (draw_pile.size() == 0 && discard_pile.size() == 0) {
		return false;
	}
	else if (draw_pile.size() == 0) {
		shuffle(discard_pile.begin(), discard_pile.end(), random_device());
		move(discard_pile.begin(), discard_pile.end(), back_inserter(draw_pile));
		discard_pile.erase(discard_pile.begin(), discard_pile.end());
	}
	current_card = draw_pile[0];
	draw_pile.erase(draw_pile.begin());

	return true;
}

void Player::set_joker_value(string value) {
	current_card = value + "J";
}

string Player::top_playing_card() {
	return current_card;
}
void Player::set_playing_card(string card) {
	current_card = card;
}

string Player::get_reserve() {
	return reserve_card;
}
void Player::change_reserve(string card) {
	reserve_card = card;
}

int Player::draw_size() {
	return draw_pile.size();

}
int Player::discard_size() {
	return discard_pile.size();
}

int Player::get_play_count() {
	return play_count;
}
void Player::set_play_count(int number) {
	play_count = number;
}
