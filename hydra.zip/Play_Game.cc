#include <string>
#include <algorithm>
#include <iostream>
#include <random>
#include <vector>
#include <map>
#include "Board.h"
#include "Player.h"
#include "Play_Game.h"


using namespace std;


Play_Game::Play_Game(bool testing) {
	player_count = 1;
	testing_mode = testing;
}

void Play_Game::switch_deck() {
	players[player_count - 1]->set_play_count(players[player_count - 1]->get_play_count() - 1);
	if (!players[player_count - 1]->switch_deck()) {
		players[player_count - 1]->set_play_count(0);
		players[player_count - 1]->set_playing_card("");
	}
}

void Play_Game::new_game(bool testing) {
	map<int, vector<string>>::iterator it = card_heads.begin();
	players[player_count - 1]->switch_deck();
	if (testing) {
		game_in_testing();
	} else {
		it->second.push_back(players[player_count - 1]->top_playing_card());
		end_turn();
		print_initiate_move();
		while (!players[player_count - 1]->winning_deck()) {
			start_turn();
		}
	}
}

void Play_Game::end_game(){
	print_anything("Player " + to_string(player_count) + " wins!\n");
	exit(0);
}

string Play_Game::head_card(int i) {
	return card_heads[i][0];
}

void Play_Game::start_turn() {
	if (players.size() > player_count) {
		player_count++;
	}
	else {
		player_count = 1;
		print_initiate_move();
	}
	print_anything("Player " + to_string(player_count) + ", it is your turn.\n");
	players[player_count - 1]->set_play_count(card_heads.size());
	player_turn();
}



string Play_Game::get_suit_testing_card() {
	string suit = "";
	print_anything("Which card suite?\n");
	while (true) {
		if (!(cin >> suit)) {
			if (cin.eof()) {
				cin.clear();
				cin.ignore();
				exit(0);
			}
		} else {
			if ((suit.length() >= 2) || (suit != "H" && suit != "D" && suit != "S" && suit != "C")) {
				print_anything("Invalid Suit.\n");
				print_anything("Which card suite?\n");
			} else {
				return suit;
			}
		}

	}
}
string Play_Game::get_testing_card() {
	string value = "";
	print_anything("Which card value?\n");
	while (true){
		if (!(cin >> value)) {
			if (cin.eof()) {
				cin.clear();
				cin.ignore();
				exit(0);
			}
		} else {
			if(get_card_value(value) == -1) {
				print_anything("Invalid Value.\n");
				print_anything("Which card value?\n");
			} else {
				return value;
			}
		}
	}
}

void Play_Game::game_in_testing() {
	string value = get_testing_card();
	if (value == "joker") {
		players[player_count - 1]->set_playing_card(value);
		return;
	} else {
		string suit = get_suit_testing_card();
		players[player_count - 1]->set_playing_card(value);
	}
}

void Play_Game::player_turn() {
	bool draw_card = true;
	while (!(players[player_count - 1]->winning_deck())
		&& ((players[player_count - 1]->get_play_count() > 0) || 
		(players[player_count - 1]->get_play_count() == 0 && players[player_count - 1]->top_playing_card() != ""))) {
		if (draw_card) {
			switch_deck();
		}
		if (players[player_count - 1]->top_playing_card() == "") {
			break;
		}
		printGameAction(player_count);
		if (draw_card && testing_mode) {
			game_in_testing();
		}
		draw_card = true;
		print_anything("Player " + to_string(player_count) + " you are holding a");
		
		if (players[player_count - 1]->top_playing_card()[0] == '8' || players[player_count - 1]->top_playing_card()[0] == 'A') {
			print_anything("n");
		}
		print_anything(" " + players[player_count - 1]->top_playing_card() + ". Your move?\n");
		int cmd;
		cin >> cmd;
		if (cin.eof()) {
			cin.clear();
			cin.ignore();
			exit(0);
		}
		print_anything("\n");
		if (cmd == 0) {
			if (players[player_count - 1]->get_reserve() == "") {
				draw_card = true;
			}
			else {
				draw_card = false;
			}
			players[player_count - 1]->switch_current_reserve();
		} else if (card_heads.find(cmd) != card_heads.end())  {
			if (players[player_count - 1]->top_playing_card() == "joker") {
				string jokerValue;
				jokerValue = get_testing_card();
				players[player_count - 1]->set_joker_value(jokerValue);
				draw_card = true;
			}
			if (draw_card) {
				if ((players[player_count - 1]->top_playing_card()[players[player_count - 1]->top_playing_card().size() - 1] != 'J') &&
				!valid_play(players[player_count - 1]->top_playing_card())) {
					head_split();
				}
				else if (((get_card_value(head_card(cmd)) != 1) && (get_card_value(players[player_count - 1]->top_playing_card()) > get_card_value(head_card(cmd))))
					&& (players[player_count - 1]->top_playing_card()[players[player_count - 1]->top_playing_card().size() - 1] != head_card(cmd)[head_card(cmd).size() - 1])){
					print_anything("Invalid command. \n");
					draw_card = false;
					if (players[player_count - 1]->top_playing_card()[players[player_count - 1]->top_playing_card().size() - 1] == 'J') {
						players[player_count - 1]->set_playing_card("joker");
					}
				} else {
					head_play_card(cmd);
				}
			}
		} else {
			print_anything("Invalid command. \n");
			draw_card = false;
		}
	}
	end_turn();
}

void Play_Game::end_turn() {
	players[player_count - 1]->set_playing_card("");
	players[player_count - 1]->reserve_to_discard();
}

void Play_Game::head_play_card(int headNum){
 	if (get_card_value(players[player_count - 1]->top_playing_card()) == get_card_value(head_card(headNum))) {
		players[player_count - 1]->set_play_count(0);
	}
	map<int, vector<string>>::iterator it = card_heads.find(headNum);
	it->second.insert(it->second.begin(), players[player_count - 1]->top_playing_card());
	players[player_count - 1]->set_playing_card("");
}

void Play_Game::head_split() {
	map<int, vector<string>>::iterator it = card_heads.begin();
	players[player_count - 1]->add_head(it->second);
	players[player_count - 1]->reserve_to_discard();
	players[player_count - 1]->current_to_discard();
	for (int i = 0; i < 2; i++) {
		switch_deck();
		if (testing_mode) {
			game_in_testing();
		}
		vector<string> temp;
		temp.push_back(players[player_count - 1]->top_playing_card());
		card_heads.insert({ card_heads.rbegin()->first + 1 , temp });
	}
	card_heads.erase(it->first);
	players[player_count - 1]->set_play_count(0);
	players[player_count - 1]->set_playing_card("");
}



