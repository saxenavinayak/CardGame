#ifndef board
#define board
#include <algorithm>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include "Player.h"
#include <memory>
#include "Base_print.h"
#include <random>
using namespace std;


class Board {

protected:
	vector<shared_ptr<Player>> players;
	vector<shared_ptr<Base_print>> print_display;
	map<int, vector<string>> card_heads;

public:
	Board();
	// Generates 54*n cards and shuffles them
	void generate_cards(vector<string> *deck, int n);
	// Adds a vector to print class
	void print_functions(shared_ptr<Base_print> print_display);
	// Adds a new player to vector of players
	void new_player(shared_ptr<Player> player);
	// Initializes the necessary fields and starts game
	virtual void new_game(bool testing) = 0;
	// Ends game, prints necessary output
	virtual void end_game() = 0;
	// Returns numerical value of card, -1 if invalid
	int get_card_value(string card);
	// Determines if the card being played is playable given the conditions of the board
	bool valid_play(string card);
	// Necessary printing functions (see TextDisplay.h)
	void print_initiate_move();
	void print_anything(string terminal_output);
	void printGameAction(int player_count);
	// Given the index, returns a player
	shared_ptr<Player> which_player_turn(int player_number);
	// Returns all card_heads currently in player
	map<int, vector<string>>& heads_in_play();
	// Returns the amount of players playing
	int players_in_play();
};

#endif