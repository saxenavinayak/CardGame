#ifndef PRINTINTERFACE
#define PRINTINTERFACE
#include <string>
#include <memory>
#include <string>
#include <iostream>
#include "Board.h"
#include <vector>

using namespace std;
class Board;
class Base_print {

protected:

	weak_ptr<Board> game_display;
public:
	Base_print(shared_ptr<Board> &g);
	virtual void print_heads() = 0;
	virtual void print_players(int player_count) = 0;
	virtual void print_anything(string genString) = 0;
	virtual void print_initiate_move() = 0;
	virtual void print_action_made(int player_count) = 0;
};

#endif

