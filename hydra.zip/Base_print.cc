#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <random>
#include "Board.h"
#include "Play_Game.h"
#include "Base_print.h"

class Board;
Base_print::Base_print(shared_ptr<Board> &g)
{
	game_display = g;
}


