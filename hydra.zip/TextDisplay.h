#ifndef PRINTCONSOLE
#define PRINTCONSOLE

#include <string>
#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include "Base_print.h"
#include "Board.h"

using namespace std;

class TextDisplay : public Base_print {
public:
	TextDisplay(shared_ptr<Board> &g);
	//void printRound(int roundCounter);
	// Prints out all the card_heads currently in play
	void print_heads();
	// Prints out all the players and their hands
	void print_players(int player_count);
	// Prints out anything desired to handle corner cases
	void print_anything(string s);
	// Prints out a single player move
	void print_initiate_move();
	// Prints information before each round (card_heads and players)
	void print_action_made(int player_count);
};

#endif
