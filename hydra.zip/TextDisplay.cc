#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <random>
#include <memory>
#include "Board.h"
#include "Play_Game.h"
#include "TextDisplay.h"
using namespace std;

TextDisplay::TextDisplay(shared_ptr<Board> &g) : Base_print(g) {}

void TextDisplay::print_initiate_move() {
	print_heads();
	print_players(0);
}




void TextDisplay::print_players(int player_count) {
	cout << "Players:" << endl;
	for (int i = 0; i < shared_ptr<Board>(game_display)->players_in_play(); i++) {
		cout << "Player " << i + 1 << ": " << shared_ptr<Board>(game_display)->which_player_turn(i)->draw_size() + shared_ptr<Board>(game_display)->which_player_turn(i)->discard_size();
		cout << " (" << shared_ptr<Board>(game_display)->which_player_turn(i)->draw_size() << " draw, " << shared_ptr<Board>(game_display)->which_player_turn(i)->discard_size() << " discard)";
		if ((player_count > 0) && (shared_ptr<Board>(game_display)->which_player_turn(i) == shared_ptr<Board>(game_display)->which_player_turn(player_count - 1))) {
			cout << " + 1 in hand, " << shared_ptr<Board>(game_display)->which_player_turn(i)->get_play_count() << " remaining, ";
			if (shared_ptr<Board>(game_display)->which_player_turn(i)->get_reserve() == "") {
				cout << 0;
			}
			else {
				cout << 1;
			}
			cout << " in reserve." << endl;
	}
		else {
			cout << endl;
		}
	}
	cout << endl;
}

void TextDisplay::print_heads() {
	cout << "Heads:" << endl;
	for (map<int, vector<string>>::iterator it = shared_ptr<Board>(game_display)->heads_in_play().begin(); it != shared_ptr<Board>(game_display)->heads_in_play().end(); ++it) {
		cout << it->first << ": ";
		cout << it->second[0] << " ";
		cout << "(" << it->second.size() << ")" << endl;
	}
	cout << endl;
}

void TextDisplay::print_anything(string s) {
	cout << s;
}

void TextDisplay::print_action_made(int player_count) {
	print_heads();
	print_players(player_count);
}




