#include <algorithm>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <random>
#include "Board.h"
#include "Player.h"
#include "Play_Game.h"
#include <memory>

using namespace std;

Board::Board() {
	vector<string> head;
	card_heads.insert({ 1, head });
}
void Board::generate_cards(vector<string> *deck, int n) {
	for (int i = 0; i < n; i++) {
		for (int s = 1; s <= 4; s++) {
			for (int v = 1; v <= 13; v++) {
				string suit = "";
				string value = "";
				if (s == 1) {
					suit = "S"; //Spades
				} else if (s == 2) {
					suit = "H"; //Hearts
				} else if (s == 3){
					suit = "C"; //Clubs
				} else {
					suit = "D"; //Diamonds
				}
				if (v == 1) {
					value = "A";
				} else if (v == 11) {
					value = "J";
				} else if (v == 12) {
					value = "Q";
				} else if (v == 13) {
					value = "K";
				} else {
					value = to_string(v);
				}
				string card_type = value + suit;
				
				deck->push_back(card_type);
			}
		}
		for (int j = 0; j < 2; j++)
		{
			deck->push_back("joker");
		}
	}
	shuffle(deck->begin(), deck->end(), random_device());
}

void Board::new_player(shared_ptr<Player> player){
	players.push_back(move(player));
}

shared_ptr<Player> Board::which_player_turn(int player_number){
	return players[player_number];
}
map<int, vector<string>>& Board::heads_in_play(){
	return card_heads;
}
int Board::players_in_play(){
	return players.size();
}

void Board::print_initiate_move() {
	for (int i = 0; i < print_display.size(); i++) {
		print_display[i]->print_initiate_move();
	}
}

void Board::printGameAction(int player_count) {
	for (int i = 0; i < print_display.size(); i++) {
	print_display[i]->print_action_made(player_count);
	}
}
void Board::print_anything(string terminal_output) {
	for (int i = 0; i < print_display.size(); i++) {
		print_display[i]->print_anything(terminal_output);
	}
}
void Board::print_functions(shared_ptr<Base_print> print_display) {
	this->print_display.push_back(move(print_display));
}



int Board::get_card_value(string card) {
	if((card.length() > 2) && (card != "joker")) {
		return -1;
	}
	if (card[0] == 'A') {
		return 1;
	}
	else if (card == "joker") {
		return 2;
	}
	else if (((int)card[0] - 48) > 1 && ((int)card[0] - 48) < 10) {
		return (int)card[0] - 48;
	}
	else if ((card[0] == '1') && (card[1] == '0')){
		return 10;
	}
	else if (card[0] == 'K') {
		return 13;
	}
	else if (card[0] == 'Q') {
		return 12;
	}
	else if (card[0] == 'J') {
		return 11;
	}
	else {
		return -1;
	}
}



bool Board::valid_play(string card) {
	for (map<int, vector<string>>::iterator it = card_heads.begin(); it != card_heads.end(); ++it) {
		if (get_card_value(card) <= get_card_value(it->second[0]) || get_card_value(it->second[0]) == 1) {
			return true;
		}
	}
	return false;
}



